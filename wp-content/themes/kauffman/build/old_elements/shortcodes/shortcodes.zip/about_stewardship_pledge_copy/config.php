<?php if (!defined('FW')) {
  die('Forbidden');
}

$cfg = array(
  'page_builder' => array(
  'title'         => __('Stewardship pledge 2 (Full width)', '{domain}'),
  'description'   => __('', '{domain}'),
  'tab'           => __('About', '{domain}'),
  'popup_size'    => 'large', // can be large, medium or small
  )
);