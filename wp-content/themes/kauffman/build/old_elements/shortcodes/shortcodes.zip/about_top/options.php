<?php if (!defined('FW')) {
  die('Forbidden');
}

$options = array(
  
'title' => array(
'type'  => 'text',
'value' => 'Developing leaders in innovation &&nbspcapital&nbspformation through 2-year program.',
'label' => __('title', '{domain}')
),

'text' => array(
'type'  => 'text',
'value' => 'Transformative opportunity designed to radically accelerate innovator success through through self-reflection, peer learning, mentoring, and a structured curriculum taught by venture capitalists and global thought leaders.',
'label' => __('text', '{domain}')
),

'margin_top' => array(
'type'  => 'text',
'value' => '160',
'label' => __('margin-top', '{domain}')
),

'margin_bottom' => array(
'type'  => 'text',
'value' => '0',
'label' => __('margin-bottom', '{domain}')
),

'image' => array(
'type'  => 'upload',
'value' => array(
  'attachment_id' => '474'
),
  
'label' => __('background', '{domain}'),
'images_only' => true,
'files_ext' => array( 'gif', 'bmp', 'png', 'jpeg', 'jpg'),
),
  
'data_aos' => array(
'type'  => 'text',
'value' => '',
'label' => __('data-aos', '{domain}')
)
);