<?php if (!defined('FW')) {
	die('Forbidden');
}

$options = array(
	'is_fullwidth' => array(
		'label'        => __('Full Width', 'fw'),
		'type'         => 'switch',
	),
	'background_color' => array(
		'label' => __('Background Color', 'fw'),
		'desc'  => __('Please select the background color', 'fw'),
		'type'  => 'color-picker',
	),
	'background_image' => array(
		'label'   => __('Background Image', 'fw'),
		'desc'    => __('Please select the background image', 'fw'),
		'type'    => 'background-image',
		'choices' => array(//	in future may will set predefined images
		)
	),
	'video' => array(
		'label' => __('Background Video', 'fw'),
		'desc'  => __('Insert Video URL to embed this video', 'fw'),
		'type'  => 'text',
	),
  'id' => array(
    'label' => __('id', 'fw'),
    'desc'  => __('Insert id', 'fw'),
    'type'  => 'text',
  ),
  'class' => array(
    'label' => __('class', 'fw'),
    'desc'  => __('Insert class', 'fw'),
    'type'  => 'text',
  ),
  'container_class' => array(
    'label' => __('Container class', 'fw'),
    'desc'  => __('Insert container class', 'fw'),
    'type'  => 'text',
  ),
  'is_mobile_top' => array(
  'label'        => __('Mobile margin-top 100px', 'fw'),
  'type'         => 'switch',
  ),
  'margin_top' => array(
  'type'  => 'text',
  'value' => '0',
  'label' => __('margin-top', '{domain}')
  ),
  'margin_bottom' => array(
  'type'  => 'text',
  'value' => '0',
  'label' => __('margin-bottom', '{domain}')
  ),

'data_aos' => array(
'type'  => 'text',
'value' => '',
'label' => __('data-aos', '{domain}')
)
);
