<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

/**
 * @var array $atts
 */
?>

<div class="g_text">
	<?php echo do_shortcode( $atts['text'] ); ?>
</div>
	