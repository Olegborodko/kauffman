<?php if (!defined('FW')) {
  die('Forbidden');
}

$options = array(
  'top' => array(
    'type'  => 'text',
    'value' => '342',
    'label' => __('top', '{domain}')
  ),

  'text' => array(
    'type'  => 'text',
    'value' => 'what’s on right now',
    'label' => __('text', '{domain}')
  ),

'data_aos' => array(
'type'  => 'text',
'value' => '',
'label' => __('data-aos', '{domain}')
)
);