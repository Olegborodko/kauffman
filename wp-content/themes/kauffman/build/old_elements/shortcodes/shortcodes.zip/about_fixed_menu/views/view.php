<?php if (!defined('FW')) {
  die('Forbidden');
}

//var_dump(fw_get_db_settings_option('items'));
if ( ! empty( $atts['items'] ) ) {
  
}else{
  return;
}

$top = 0;
if ( ! empty( $atts['top'] ) ) {
  $top = (int) $atts['top'];
}

?>

<div class="apply_section_right_fixed lavalamp-menu" id="menu_spy" style="top: <?=$top?>px">
  <nav>
    <ul>

      <?php
      $isFirst = true;
      foreach ( $atts['items'] as $key => $value ) {
        if($isFirst){
          echo '<li class="active">';
        }else{
          echo '<li>';
        }
        ?>
          <a href="<?=$value['link_url']?>">
            <?=$value['link_text']?>
          </a>
        </li>
      
      <?php
        $isFirst = false;
      }
      ?>

    </ul>
    <div class="lavalamp js_lavalamp"></div>
  </nav>
</div>
<div class="apply_section_right_line"></div>