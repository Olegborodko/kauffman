<?php if (!defined('FW')) {
  die('Forbidden');
}

$options = array(

'title' => array(
'type'  => 'text',
'value' => 'Press Releases',
'label' => __('title', '{domain}')
),

'text' => array(
'type'  => 'text',
'value' => 'Press materials are intended for journalists for a professional use. Subscribe to Kauffman Fellows press releases below.',
'label' => __('text', '{domain}')
),

'margin_top' => array(
'type'  => 'text',
'value' => '0',
'label' => __('margin-top', '{domain}')
),

'margin_bottom' => array(
'type'  => 'text',
'value' => '0',
'label' => __('margin-bottom', '{domain}')
),

'data_aos' => array(
'type'  => 'text',
'value' => '',
'label' => __('data-aos', '{domain}')
)
  
);