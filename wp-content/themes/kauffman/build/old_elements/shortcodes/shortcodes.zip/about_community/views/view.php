<?php if (!defined('FW')) {
  die('Forbidden');
}

$margin_top = 0;
if ( ! empty( $atts['margin_top'] ) ) {
  $margin_top = (int) $atts['margin_top'];
}

$margin_bottom = 0;
if ( ! empty( $atts['margin_bottom'] ) ) {
  $margin_bottom = (int) $atts['margin_bottom'];
}

$data_aos = '';
if ( ! empty( $atts['data_aos'] ) ) {
  $data_aos = $atts['data_aos'];
}
?>

<div data-aos="<?=$data_aos?>" class="col g_mobile_margin_100" style="margin-top: <?= $margin_top ?>px; margin-bottom: <?= $margin_bottom ?>px">
  <div>
    <ul class="tabs clearfix" data-tabgroup="first-tab-group">
      <li><a href="#tab1" class="active">Africa</a></li>
      <li><a href="#tab2">Asia</a></li>
      <li><a href="#tab3">Australia</a></li>
      <li><a href="#tab4">Europe</a></li>
      <li><a href="#tab5">North America</a></li>
      <li><a href="#tab6">South America</a></li>
    </ul>
    <div id="first-tab-group" class="tabgroup">
      <div id="tab1" class="companies-tab" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/img/africa.png);
      background-position: top center;
      background-size: initial!important;">
        <?=$atts['tab1']?>
      </div>
      <div id="tab2" class="companies-tab" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/img/africa.png);
      background-position: top center;
      background-size: initial!important;">
        <?=$atts['tab2']?>
      </div>
      <div id="tab3" class="companies-tab" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/img/africa.png);
      background-position: top center;
      background-size: initial!important;">
        <?=$atts['tab3']?>
      </div>
      <div id="tab4" class="companies-tab" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/img/africa.png);
      background-position: top center;
      background-size: initial!important;">
        <?=$atts['tab4']?>
      </div>
      <div id="tab5" class="companies-tab" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/img/africa.png);
      background-position: top center;
      background-size: initial!important;">
        <?=$atts['tab5']?>
      </div>
      <div id="tab6" class="companies-tab" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/img/africa.png);
      background-position: top center;
      background-size: initial!important;">
        <?=$atts['tab6']?>
      </div>
    </div>
  </div>
</div>