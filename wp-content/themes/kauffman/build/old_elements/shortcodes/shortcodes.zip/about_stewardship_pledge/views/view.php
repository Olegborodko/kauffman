<?php if (!defined('FW')) {
  die('Forbidden');
}

$margin_top = 0;
if ( ! empty( $atts['margin_top'] ) ) {
  $margin_top = (int) $atts['margin_top'];
}

$margin_bottom = 0;
if ( ! empty( $atts['margin_bottom'] ) ) {
  $margin_bottom = (int) $atts['margin_bottom'];
}

$data_aos = '';
if ( ! empty( $atts['data_aos'] ) ) {
  $data_aos = $atts['data_aos'];
}
?>

<div data-aos="fade" data-aos="<?=$data_aos?>" style="margin-top: <?= $margin_top ?>px; margin-bottom: <?= $margin_bottom ?>px">
  <div class="row" style="margin-bottom: 140px">
    <div class="col-lg-10 offset-lg-1">
      <div class="about-pledge-border"></div>
      <div class="about-pledge-border2"></div>
      <div class="row">
        <div class="col-lg-10 offset-lg-1 no-gutters">
          <div class="about-pledge__content">
            <div class="about-pledge-header">
              <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/svg/pledge_logo.svg" alt="" class="about-pledge-header__img">
              <span class="about-pledge-header__line"></span>
            </div>
            <span class="about-pledge__title">Stewardship Pledge for&nbspthe Innovation Investor</span>
            <span class="about-pledge-content__text">As an investor in innovation, I recognize:</span>
            <ul class="about-pledge__top-list">
              <li>Our industry of innovation capital has the power to drive both private value creation and sustainable, positive societal transformation.</li>
              <li>My purpose is to direct capital and expertise to create shared value by accelerating the pace of innovation through company formation and growth.</li>
              <li>My investment decisions affect the well-being of individuals inside and outside my own organization, the companies in which we invest, my capital partners, the industries in which we work, and beyond, both today and in the future.</li>
            </ul>

            <div class="g_text_align_right">
              <a class="releases__more-btn js_read_more_btn">read more</a>
            </div>

            <div class="js_read_more_block">
              <span class="about-pledge-content__text">Therefore, in the spirit of stewardship toward all my stakeholders, I acknowledge and pledge the following:</span>
              <ol class="about-pledge__numbers-list">
                <li><span>01.</span>I will not advance my own interests at the expense of my organization, my investee companies, my capital partners, or society.</li>
                <li><span>02.</span>I will manage my investments with loyalty and care and I will report the performance and risks of my organization and my investee companies accurately and honestly to my capital partners.</li>
                <li><span>03.</span>I will understand and uphold, in letter and in spirit, the laws and contracts governing my conduct and that of my enterprise and my investee companies, and refrain from corruption, unfair competition, or other business practices harmful to society.</li>
                <li><span>04.</span>I will recognize the power imbalance inherent in the relationship between investor and entrepreneur, and will not abuse my position, engage in sexual harassment or discrimination, or condone it in the organizations and communities around me.</li>
                <li><span>05.</span>I will protect the human rights and dignity of all people impacted by my organization and my investee companies, and oppose discrimination both within my investee companies and in the process of selecting investments.</li>
                <li><span>06.</span>I will promote a culture of inclusion, seek out diversity of all types, and foster a sense of belonging among all the organizations and communities in which I work.  To further continuing awareness and action, I will participate to the extent of my abilities in open discussion and reporting across our industry as well as encourage others to do the same.</li>
                <li><span>07.</span>I will develop myself, and coach, mentor, and apprentice the next generation of investors.</li>
                <li><span>08.</span>I will work with my stakeholders to support sustainable inclusive prosperity and to minimize the negative consequences of our actions to the environment and society.</li>
              </ol>
              <span class="about-pledge__bottom-text">In exercising my professional commitments according to these principles, I recognize that my behavior must set an example of integrity and mutual respect, eliciting trust and esteem from the multiple stakeholders I serve. I will remain accountable to my peers and to society for my actions and for upholding these standards.</span>
              <span class="about-pledge__name">Entire Kauffman Fellows</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>