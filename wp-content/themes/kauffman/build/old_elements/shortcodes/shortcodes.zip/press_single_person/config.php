<?php if (!defined('FW')) {
  die('Forbidden');
}

$cfg = array(
  'page_builder' => array(
  'title'         => __('Press single person', '{domain}'),
  'description'   => __('', '{domain}'),
  'tab'           => __('Press single', '{domain}'),
  'popup_size'    => 'small', // can be large, medium or small
  )
);