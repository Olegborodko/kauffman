<?php if (!defined('FW')) {
  die('Forbidden');
}

$options = array(
'title' => array(
'type'  => 'text',
'value' => 'Ewing Marion Kauffman',
'label' => __('title', '{domain}')
),

'text' => array(
'type'  => 'textarea',
'value' => 'Inspired by his legacy of shared ownership, accountability & experimentation, we measure success in enduring new businesses that generate long-term returns for principals, investors, and society as a whole.',
'label' => __('text', '{domain}')
),

'margin_top' => array(
'type'  => 'text',
'value' => '160',
'label' => __('margin-top', '{domain}')
),

'margin_bottom' => array(
'type'  => 'text',
'value' => '0',
'label' => __('margin-bottom', '{domain}')
),

'image' => array(
'type'  => 'upload',
'value' => array(),
'label' => __('image', '{domain}'),
'images_only' => true,
'files_ext' => array( 'gif', 'bmp', 'png', 'jpeg', 'jpg'),
),

'data_aos' => array(
'type'  => 'text',
'value' => '',
'label' => __('data-aos', '{domain}')
)
);